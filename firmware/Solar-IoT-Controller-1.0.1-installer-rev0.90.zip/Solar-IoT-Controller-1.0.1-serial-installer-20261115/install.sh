#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if [[ "$(uname -s)" != Linux || "$(uname -m)" != x86_64 ]]; then
  echo 'This bundled installer supports Linux x86_64. Use the Windows installer on Windows x64.'; exit 1
fi
verify() { sha256sum --check SHA256SUMS.txt; }
verify
if [[ "${1:-}" == --verify-only ]]; then exit 0; fi
TOOL=./tools/linux-x64/esptool
chmod +x "$TOOL"
echo 'Solar-IoT ESP32-WROOM32 / 4MB - Serial installer'
echo '1) Update existing device (partition must match; keeps NVS configuration)'
echo '2) Full installation for new board / recovery (writes bootloader + partition table)'
read -r -p 'Mode [1/2]: ' mode
case "$mode" in 1|2) ;; *) echo 'Cancelled'; exit 1;; esac
printf 'Available serial devices:\n'
for port in /dev/ttyUSB* /dev/ttyACM*; do [[ ! -e "$port" ]] || printf '  %s\n' "$port"; done
read -r -p 'Serial port (e.g. /dev/ttyUSB0): ' port
[[ "$port" == /dev/* && "$port" != *[[:space:]]* ]] || { echo 'Invalid port'; exit 1; }
echo 'Close serial monitors. Disconnect RS485 from the programming UART. Use stable board power.'
if [[ "$mode" == 1 ]]; then
  read -r -p 'Type UPDATE to proceed: ' answer
  [[ "$answer" == UPDATE ]] || { echo 'Cancelled'; exit 1; }
  probe=$(mktemp)
  trap 'rm -f "$probe"' EXIT
  "$TOOL" --chip esp32 --port "$port" --baud 115200 --after no_reset read_flash 0x8000 3072 "$probe"
  cmp --silent firmware/partitions.bin "$probe" || { echo 'Partition mismatch: no write performed. Contact support before changing partitions.'; exit 1; }
  "$TOOL" --chip esp32 --port "$port" --baud 115200 --before no_reset --after hard_reset write_flash --flash_mode dio --flash_freq 40m --flash_size 4MB 0xe000 firmware/boot_app0.bin 0x10000 firmware/firmware.bin
else
  echo 'Full installation changes the bootloader and partition table. Use only the supported Solar-IoT board.'
  read -r -p 'Type INSTALL to proceed: ' answer
  [[ "$answer" == INSTALL ]] || { echo 'Cancelled'; exit 1; }
  "$TOOL" --chip esp32 --port "$port" --baud 115200 --after hard_reset write_flash --flash_mode dio --flash_freq 40m --flash_size 4MB 0x1000 firmware/bootloader.bin 0x8000 firmware/partitions.bin 0xe000 firmware/boot_app0.bin 0x10000 firmware/firmware.bin
fi
echo 'Completed. If necessary, release BOOT and reset the board. Open the Local Web to verify the version and settings.'
