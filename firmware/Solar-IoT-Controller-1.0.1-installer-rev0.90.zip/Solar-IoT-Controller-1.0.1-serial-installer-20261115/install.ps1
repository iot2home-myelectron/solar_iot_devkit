$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
try {
    foreach ($line in Get-Content -LiteralPath 'SHA256SUMS.txt') {
        if ($line -notmatch '^([0-9a-f]{64})  (.+)$') { throw 'Invalid checksum manifest' }
        $expected = $Matches[1]; $relative = $Matches[2]
        $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $PSScriptRoot $relative)).Hash.ToLowerInvariant()
        if ($actual -ne $expected) { throw "Checksum mismatch: $relative. Download the ZIP again." }
    }
    $tool = Join-Path $PSScriptRoot 'tools\windows-x64\esptool.exe'
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'Windows x64 is required.' }
    Write-Host 'Solar-IoT ESP32-WROOM32 / 4MB - Serial installer'
    Write-Host '1) Update existing device (partition must match; keeps NVS configuration)'
    Write-Host '2) Full installation for new board / recovery'
    $mode = Read-Host 'Mode [1/2]'
    if ($mode -notin @('1','2')) { throw 'Cancelled' }
    try { Get-CimInstance Win32_SerialPort | Format-Table DeviceID, Name -AutoSize | Out-Host } catch { Write-Host 'Check Device Manager for the COM port.' }
    $port = (Read-Host 'Serial port (e.g. COM3)').Trim().ToUpperInvariant()
    if ($port -notmatch '^COM[0-9]+$') { throw 'Invalid COM port' }
    Write-Host 'Close serial monitors. Disconnect RS485 from the programming UART. Use stable board power.'
    if ($mode -eq '1') {
        if ((Read-Host 'Type UPDATE to proceed') -cne 'UPDATE') { throw 'Cancelled' }
        $probe = [IO.Path]::GetTempFileName()
        try {
            & $tool --chip esp32 --port $port --baud 115200 --after no_reset read_flash 0x8000 3072 $probe
            if ($LASTEXITCODE -ne 0) { throw 'Cannot read partition table; nothing written.' }
            if ((Get-FileHash -Algorithm SHA256 -LiteralPath $probe).Hash -ne (Get-FileHash -Algorithm SHA256 -LiteralPath 'firmware\partitions.bin').Hash) { throw 'Partition mismatch: no write performed. Contact support.' }
            & $tool --chip esp32 --port $port --baud 115200 --before no_reset --after hard_reset write_flash --flash_mode dio --flash_freq 40m --flash_size 4MB 0xe000 firmware/boot_app0.bin 0x10000 firmware/firmware.bin
            if ($LASTEXITCODE -ne 0) { throw 'Firmware write failed. Do not erase flash; check wiring and power before retrying.' }
        } finally { Remove-Item -LiteralPath $probe -ErrorAction SilentlyContinue }
    } else {
        Write-Host 'Full installation changes bootloader and partition table. Use only the supported Solar-IoT board.'
        if ((Read-Host 'Type INSTALL to proceed') -cne 'INSTALL') { throw 'Cancelled' }
        & $tool --chip esp32 --port $port --baud 115200 --after hard_reset write_flash --flash_mode dio --flash_freq 40m --flash_size 4MB 0x1000 firmware/bootloader.bin 0x8000 firmware/partitions.bin 0xe000 firmware/boot_app0.bin 0x10000 firmware/firmware.bin
        if ($LASTEXITCODE -ne 0) { throw 'Firmware write failed. Check wiring and power before retrying.' }
    }
    Write-Host 'Completed. Release BOOT and reset if necessary. Verify the version and settings in the Local Web.'
    exit 0
} catch { Write-Host ("ERROR: " + $_.Exception.Message) -ForegroundColor Red; exit 1 }
