@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
set "install_result=%errorlevel%"
echo.
if not "%install_result%"=="0" echo Installation failed or cancelled. Read the message above before retrying.
pause
exit /b %install_result%
