# ติดตั้ง Solar-IoT Controller ผ่าน Serial

สำหรับ Solar-IoT Controller 1.0.1 บอร์ด ESP32-WROOM32 / Flash 4MB เท่านั้น

## ใน ZIP มีอะไร

- Install.cmd / install.ps1 สำหรับ Windows x64 และ install.sh สำหรับ Linux x86_64
- esptool 4.11.0 แบบ standalone จาก official Espressif release ไม่ต้องติดตั้ง Python หรือ PlatformIO
- firmware/ มีโปรแกรม, bootloader, partition และข้อมูลเลือกบูต
- README-TH.md คู่มือการติดตั้งฉบับนี้
- manifest.json / SHA256SUMS.txt ข้อมูลรุ่นและค่าตรวจสอบความครบถ้วน
- third-party/ มี source archive และ license/provenance ของ esptool

ไฟล์นี้ไม่ได้ติดตั้ง driver USB ให้ หากยังไม่เห็น COM port ให้ติดตั้ง driver ที่ตรงกับ USB-to-UART ของคุณจากผู้ผลิต

## ก่อนเริ่ม

1. แตก ZIP ทั้งหมดออกเป็นโฟลเดอร์ก่อน ห้ามรันจากใน ZIP
2. จ่ายไฟบอร์ดให้เสถียร ใส่แบตเตอรี่ตามชุดฮาร์ดแวร์ที่ใช้ ห้ามถอดไฟระหว่างเขียน
3. ต่อ USB-to-UART ที่ระดับสัญญาณ 3.3V: TX ของ adapter ไป RX ของบอร์ด, RX ไป TX, GND ร่วมกัน
4. ถอด RS485/อุปกรณ์อื่นที่ใช้พอร์ต debug/program เดียวกัน ห้ามให้หลายอุปกรณ์ขับ UART พร้อมกัน
5. ห้ามป้อนสัญญาณ 5V เข้า GPIO และไม่ควรให้ adapter เป็นแหล่งจ่ายบอร์ดโดยไม่ตรวจวงจร
6. ปิด Serial Monitor และโปรแกรมที่ใช้ COM port นั้นทั้งหมด
7. ถ้าชุดโปรแกรมไม่มีวงจร auto-download ให้เข้า ROM download mode ด้วยวิธีของบอร์ด: GPIO0/BOOT ต้อง LOW ขณะ reset/EN แล้วปล่อย BOOT เมื่อเริ่มเชื่อมต่อได้ ขาเหล่านี้อาจต้องต่อผ่านจุด programming ของบอร์ด ไม่ใช่ tilt-switch

## Windows 64-bit

ดับเบิลคลิก Install.cmd อ่านเมนู แล้วกรอกหมายเลขโหมดและ COM port เช่น COM3
PowerShell จะถูกเรียกโดยใช้ ExecutionPolicy Bypass เฉพาะ process นี้ ไม่ได้เปลี่ยน policy ของระบบถาวร หากนโยบายองค์กรไม่อนุญาต ให้ผู้ดูแลตรวจสคริปต์ก่อน ไม่ต้องปิดระบบป้องกันทั้งเครื่อง

## Linux x86_64

เปิด terminal ในโฟลเดอร์ที่แตก ZIP แล้วรัน:

```sh
bash install.sh
```

เลือกพอร์ต เช่น /dev/ttyUSB0 หรือ /dev/ttyACM0 บัญชีต้องมีสิทธิ์เข้าพอร์ต ถ้า permission denied ให้ผู้ดูแลจัดสิทธิ์ serial port ตามระบบที่ใช้ ไม่ต้องรันทั้ง installer เป็น root

ตรวจไฟล์อย่างเดียวโดยไม่ติดต่อบอร์ดได้ด้วย `bash install.sh --verify-only`

## เลือกโหมดไหนดี

### 1 — Update existing device: แนะนำสำหรับเครื่องเดิม

- พิมพ์ UPDATE เพื่อยืนยัน
- อ่านและเทียบ partition table กับรุ่นที่แจก **ก่อนเขียน** ถ้าไม่ตรงจะหยุด ไม่มีการเขียน
- เขียน firmware ที่ app0 และข้อมูลเลือกบูตที่ 0xE000 เพื่อให้บูต app0
- ไม่เขียน partition table/bootloader และไม่ล้าง NVS จึงเก็บ settings กับ LoRa frame-counter storage เมื่อใช้ layout เดียวกัน
- การคงค่าขึ้นกับ firmware/schema ที่เข้ากันด้วย ชุดนี้ใช้ schema13 ไม่ใช่ตัวอัปเดตสากลสำหรับ firmware อื่น

### 2 — Full installation: สำหรับบอร์ดใหม่หรือกู้ระบบ

- พิมพ์ INSTALL เพื่อยืนยัน
- เขียน bootloader, partition table, ข้อมูลเลือกบูต และโปรแกรมครบชุด
- ไม่ใช่ Factory Reset: **ไม่มีคำสั่ง erase_flash** และไม่ได้รับประกันว่าค่าเดิมจะถูกล้าง
- หากเป็นเครื่องเดิมและโหมด Update แจ้ง partition ไม่ตรง อย่าใช้โหมดนี้ข้ามปัญหาทันที ให้ตรวจ layout/สำรอง/วางแผนย้ายข้อมูลกับผู้ดูแลก่อน

ตำแหน่งไฟล์ของรุ่นนี้:

| ไฟล์ | Offset |
|---|---|
| bootloader.bin | 0x1000 |
| partitions.bin | 0x8000 |
| boot_app0.bin | 0xE000 |
| firmware.bin | 0x10000 |

NVS อยู่ 0x9000 ขนาด 0x5000 ใน layout นี้ สคริปต์ไม่เขียนบริเวณดังกล่าว ไม่มีการแก้ eFuse หรือบันทึก credentials ลง ZIP

## หลังติดตั้ง

1. รอข้อความ Completed แล้วปล่อย BOOT/reset หากบอร์ดไม่เริ่มเอง
2. เปิด Local Web แล้วตรวจรุ่นและค่าที่เคยบันทึกไว้ หากเชื่อมต่อ Wi-Fi router สำเร็จให้ใช้ IP ของบอร์ดที่แสดงใน Serial log; หากเปิด Setup AP ให้เชื่อม Wi-Fi ของบอร์ดแล้วเปิด http://192.168.4.1/
3. ถ้าเป็นบอร์ดใหม่ ต้องตั้ง sensor, LoRa และ Wi-Fi/MQTT เอง ไฟล์แจกไม่มีบัญชี Wi-Fi/MQTT/LoRa ของผู้พัฒนา
4. การอัปเดต firmware ไม่ได้อัปเดตโปรแกรมใน modem RBS76-V2

**ข้อจำกัดของ firmware ที่แนบ:** build ปัจจุบันยัง bypass Web login และใช้ AP แบบไม่มีรหัสผ่านตามงานพัฒนารุ่น 1.0.1 ให้ทบทวนก่อนแจกใช้งานนอกวงทดสอบ OTA ผ่านเว็บ/Internet ยังไม่มีในรุ่นนี้ การติดตั้งชุดนี้ใช้สาย Serial

## ถ้าติดตั้งไม่สำเร็จ

- ไม่เห็นพอร์ต: ตรวจ driver, สาย, USB-to-UART และ Device Manager
- พอร์ตถูกใช้งาน: ปิด Serial Monitor/โปรแกรมอื่น
- ค้าง Connecting: ตรวจ BOOT/GPIO0, reset/EN, สาย TX/RX/GND และวิธีเข้า download mode ของบอร์ด
- อ่าน partition ผ่านแต่ขั้นเขียนต่อไม่สำเร็จ: อย่า reset ระหว่างสองขั้นตอน โหมด Update ใช้ no_reset เพื่อคง bootloader/stub ไว้จนเขียนเสร็จ
- Hash/checksum ไม่ตรง: ดาวน์โหลดและแตก ZIP ใหม่ ห้ามข้ามการตรวจ
- Partition mismatch: หยุดก่อนเขียน ติดต่อผู้ดูแลพร้อมรายละเอียดรุ่นเดิม
- ไฟดับระหว่างเขียน: อาจต้องติดตั้งผ่าน Serial ซ้ำ ไม่มีการรับประกัน rollback ของการ flash ผ่านสาย

โปรแกรมจะตรวจ chip เป็น ESP32 และใช้ baud 115200 เพื่อเน้นการเชื่อมต่อที่เสถียร การตรวจ SHA-256 ในชุดช่วยตรวจไฟล์เสีย/ไม่ครบ ไม่ใช่ digital signature; ควรเทียบ checksum ของ ZIP จากช่องทางผู้เผยแพร่ที่เชื่อถือได้ด้วย
